import { z } from "zod";

// User roles in the system
export type UserRole = "student" | "lecturer" | "admin";

// Team roles in the simulation game
export type TeamRole = 
  | "production_planner" 
  | "capacity_engineer" 
  | "lean_quality_engineer" 
  | "automation_engineer"
  | "performance_analyst";

// Production strategy types
export type ProductionMode = "MTS" | "MTO";

// Automation levels
export type AutomationLevel = "manual" | "semi_automated" | "fully_automated";

// Round phases
export type RoundPhase = "design" | "simulating" | "reviewing";

// Round types
export type RoundType = "practice" | "baseline" | "lean_quality" | "automation" | "challenge";

// User schema
export const userSchema = z.object({
  id: z.string(),
  username: z.string(),
  password: z.string(),
  role: z.enum(["student", "lecturer", "admin"]),
  displayName: z.string(),
});

export type User = z.infer<typeof userSchema>;
export type InsertUser = Omit<User, "id">;

// Team schema
export const teamSchema = z.object({
  id: z.string(),
  name: z.string(),
  sessionId: z.string(),
  members: z.array(z.object({
    id: z.string(),
    name: z.string(),
    role: z.enum(["production_planner", "capacity_engineer", "lean_quality_engineer", "automation_engineer", "performance_analyst"]),
  })),
});

export type Team = z.infer<typeof teamSchema>;
export type InsertTeam = Omit<Team, "id">;

// Product schema
export const productSchema = z.object({
  id: z.string(),
  name: z.string(),
  mode: z.enum(["MTS", "MTO"]),
  demandRate: z.number(),
  baseProcessingTime: z.number(),
  lotSize: z.number(),
  safetyStock: z.number(),
});

export type Product = z.infer<typeof productSchema>;

// Workstation schema
export const workstationSchema = z.object({
  id: z.string(),
  name: z.string(),
  position: z.number(),
  cycleTime: z.number(),
  automationLevel: z.enum(["manual", "semi_automated", "fully_automated"]),
  operatorCount: z.number(),
  machineCount: z.number(),
  wipLimit: z.number().nullable(),
  qualityCheckpoint: z.boolean(),
  maintenanceSchedule: z.enum(["none", "weekly", "daily"]),
  availability: z.number(), // percentage 0-100
  performance: z.number(), // percentage 0-100
  quality: z.number(), // percentage 0-100
});

export type Workstation = z.infer<typeof workstationSchema>;

// Production line schema
export const productionLineSchema = z.object({
  id: z.string(),
  name: z.string(),
  workstations: z.array(workstationSchema),
  shiftHours: z.number(),
  operatingDays: z.number(),
});

export type ProductionLine = z.infer<typeof productionLineSchema>;

// KPI schema for a round
export const kpiSchema = z.object({
  throughput: z.number(),
  utilizationByStation: z.record(z.string(), z.number()),
  overallUtilization: z.number(),
  oeeAvailability: z.number(),
  oeePerformance: z.number(),
  oeeQuality: z.number(),
  oeeOverall: z.number(),
  defectRate: z.number(),
  reworkRate: z.number(),
  leadTime: z.number(),
  inventory: z.number(),
  backlog: z.number(),
  bottleneckStation: z.string().nullable(),
});

export type KPI = z.infer<typeof kpiSchema>;

// Round schema
export const roundSchema = z.object({
  id: z.string(),
  roundNumber: z.number(),
  roundType: z.enum(["practice", "baseline", "lean_quality", "automation", "challenge"]),
  phase: z.enum(["design", "simulating", "reviewing"]),
  configuration: z.object({
    products: z.array(productSchema),
    productionLine: productionLineSchema,
    leanInitiatives: z.object({
      wipLimitsEnabled: z.boolean(),
      qualityCheckpointsEnabled: z.boolean(),
      layoutOptimized: z.boolean(),
    }),
    automationSettings: z.object({
      targetAutomationLevel: z.enum(["manual", "semi_automated", "fully_automated"]),
      preventiveMaintenance: z.boolean(),
    }),
  }),
  kpiResults: kpiSchema.nullable(),
  startedAt: z.string().nullable(),
  completedAt: z.string().nullable(),
});

export type Round = z.infer<typeof roundSchema>;

// Game session schema
export const gameSessionSchema = z.object({
  id: z.string(),
  name: z.string(),
  team: teamSchema,
  currentRoundIndex: z.number(),
  rounds: z.array(roundSchema),
  status: z.enum(["active", "completed", "paused"]),
  createdAt: z.string(),
});

export type GameSession = z.infer<typeof gameSessionSchema>;
export type InsertGameSession = Omit<GameSession, "id" | "createdAt">;

// Scenario template schema
export const scenarioSchema = z.object({
  id: z.string(),
  name: z.string(),
  description: z.string(),
  difficulty: z.enum(["easy", "medium", "hard"]),
  products: z.array(productSchema),
  initialProductionLine: productionLineSchema,
  targetKPIs: z.object({
    throughputMin: z.number(),
    utilizationMin: z.number(),
    oeeMin: z.number(),
    defectRateMax: z.number(),
    leadTimeMax: z.number(),
  }),
  roundConfigs: z.array(z.object({
    roundType: z.enum(["practice", "baseline", "lean_quality", "automation", "challenge"]),
    enabled: z.boolean(),
    duration: z.number(), // minutes
  })),
});

export type Scenario = z.infer<typeof scenarioSchema>;
export type InsertScenario = Omit<Scenario, "id">;

// Decision log entry
export const decisionLogSchema = z.object({
  id: z.string(),
  sessionId: z.string(),
  roundId: z.string(),
  playerId: z.string(),
  playerRole: z.enum(["production_planner", "capacity_engineer", "lean_quality_engineer", "automation_engineer", "performance_analyst"]),
  action: z.string(),
  details: z.record(z.string(), z.unknown()),
  timestamp: z.string(),
});

export type DecisionLog = z.infer<typeof decisionLogSchema>;

// Helper types for frontend state
export type RoleConfig = {
  id: TeamRole;
  name: string;
  description: string;
  icon: string;
  color: string;
};

export const ROLE_CONFIGS: RoleConfig[] = [
  {
    id: "production_planner",
    name: "Production Planner",
    description: "Configure MTS/MTO strategy, lot sizes, and production priorities",
    icon: "ClipboardList",
    color: "chart-1",
  },
  {
    id: "capacity_engineer",
    name: "Capacity Engineer",
    description: "Design line structure, balance workloads, minimize bottlenecks",
    icon: "Settings",
    color: "chart-2",
  },
  {
    id: "lean_quality_engineer",
    name: "Lean & Quality",
    description: "Identify waste, set quality checkpoints, reduce defects",
    icon: "Shield",
    color: "chart-3",
  },
  {
    id: "automation_engineer",
    name: "Automation Engineer",
    description: "Select automation levels, manage maintenance schedules",
    icon: "Cpu",
    color: "chart-4",
  },
  {
    id: "performance_analyst",
    name: "Performance Analyst",
    description: "Monitor KPIs, analyze trends, prepare recommendations",
    icon: "BarChart3",
    color: "chart-5",
  },
];

export const ROUND_TYPE_CONFIGS: Record<RoundType, { name: string; description: string; duration: number }> = {
  practice: {
    name: "Practice Round",
    description: "Learn the UI and basic production concepts",
    duration: 15,
  },
  baseline: {
    name: "Baseline MTS vs MTO",
    description: "Compare make-to-stock and make-to-order strategies",
    duration: 25,
  },
  lean_quality: {
    name: "Lean & Quality",
    description: "Apply lean principles and quality improvements",
    duration: 30,
  },
  automation: {
    name: "Automation & OEE",
    description: "Optimize with automation and improve OEE",
    duration: 30,
  },
  challenge: {
    name: "Challenge Round",
    description: "Handle high-variety scenarios and adapt to changes",
    duration: 20,
  },
};
