import { 
  type User, 
  type InsertUser, 
  type GameSession, 
  type InsertGameSession,
  type Scenario,
  type InsertScenario,
  type DecisionLog,
  type KPI,
  type Round
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  getSession(id: string): Promise<GameSession | undefined>;
  getAllSessions(): Promise<GameSession[]>;
  createSession(session: InsertGameSession): Promise<GameSession>;
  updateSession(id: string, updates: Partial<GameSession>): Promise<GameSession | undefined>;
  deleteSession(id: string): Promise<boolean>;

  getScenario(id: string): Promise<Scenario | undefined>;
  getAllScenarios(): Promise<Scenario[]>;
  createScenario(scenario: InsertScenario): Promise<Scenario>;

  logDecision(log: Omit<DecisionLog, "id" | "timestamp">): Promise<DecisionLog>;
  getDecisionLogs(sessionId: string): Promise<DecisionLog[]>;

  simulateRound(sessionId: string, roundIndex: number): Promise<KPI>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private sessions: Map<string, GameSession>;
  private scenarios: Map<string, Scenario>;
  private decisionLogs: Map<string, DecisionLog>;

  constructor() {
    this.users = new Map();
    this.sessions = new Map();
    this.scenarios = new Map();
    this.decisionLogs = new Map();

    const defaultScenario = this.createDefaultScenario();
    this.scenarios.set(defaultScenario.id, defaultScenario);
  }

  private createDefaultScenario(): Scenario {
    return {
      id: "scenario-default",
      name: "Basic Manufacturing",
      description: "A simple production line with 4 workstations",
      difficulty: "easy",
      products: [
        {
          id: "prod-1",
          name: "Product Alpha",
          mode: "MTS",
          demandRate: 50,
          baseProcessingTime: 120,
          lotSize: 100,
          safetyStock: 50,
        },
        {
          id: "prod-2",
          name: "Product Beta",
          mode: "MTO",
          demandRate: 30,
          baseProcessingTime: 150,
          lotSize: 50,
          safetyStock: 0,
        },
      ],
      initialProductionLine: {
        id: "line-1",
        name: "Main Production Line",
        workstations: [
          {
            id: "ws-1",
            name: "Assembly A",
            position: 1,
            cycleTime: 30,
            automationLevel: "manual",
            operatorCount: 2,
            machineCount: 1,
            wipLimit: null,
            qualityCheckpoint: false,
            maintenanceSchedule: "none",
            availability: 85,
            performance: 80,
            quality: 95,
          },
          {
            id: "ws-2",
            name: "Processing B",
            position: 2,
            cycleTime: 45,
            automationLevel: "manual",
            operatorCount: 1,
            machineCount: 1,
            wipLimit: null,
            qualityCheckpoint: false,
            maintenanceSchedule: "none",
            availability: 82,
            performance: 78,
            quality: 92,
          },
          {
            id: "ws-3",
            name: "Quality Check",
            position: 3,
            cycleTime: 20,
            automationLevel: "manual",
            operatorCount: 1,
            machineCount: 1,
            wipLimit: null,
            qualityCheckpoint: true,
            maintenanceSchedule: "none",
            availability: 90,
            performance: 85,
            quality: 98,
          },
          {
            id: "ws-4",
            name: "Packaging",
            position: 4,
            cycleTime: 25,
            automationLevel: "manual",
            operatorCount: 2,
            machineCount: 2,
            wipLimit: null,
            qualityCheckpoint: false,
            maintenanceSchedule: "none",
            availability: 88,
            performance: 82,
            quality: 96,
          },
        ],
        shiftHours: 8,
        operatingDays: 5,
      },
      targetKPIs: {
        throughputMin: 200,
        utilizationMin: 75,
        oeeMin: 70,
        defectRateMax: 5,
        leadTimeMax: 180,
      },
      roundConfigs: [
        { roundType: "practice", enabled: true, duration: 15 },
        { roundType: "baseline", enabled: true, duration: 25 },
        { roundType: "lean_quality", enabled: true, duration: 30 },
        { roundType: "automation", enabled: true, duration: 30 },
        { roundType: "challenge", enabled: false, duration: 20 },
      ],
    };
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getSession(id: string): Promise<GameSession | undefined> {
    return this.sessions.get(id);
  }

  async getAllSessions(): Promise<GameSession[]> {
    return Array.from(this.sessions.values());
  }

  async createSession(insertSession: InsertGameSession): Promise<GameSession> {
    const id = randomUUID();
    const session: GameSession = {
      ...insertSession,
      id,
      createdAt: new Date().toISOString(),
    };
    this.sessions.set(id, session);
    return session;
  }

  async updateSession(id: string, updates: Partial<GameSession>): Promise<GameSession | undefined> {
    const existing = this.sessions.get(id);
    if (!existing) return undefined;

    const updated = { ...existing, ...updates };
    this.sessions.set(id, updated);
    return updated;
  }

  async deleteSession(id: string): Promise<boolean> {
    return this.sessions.delete(id);
  }

  async getScenario(id: string): Promise<Scenario | undefined> {
    return this.scenarios.get(id);
  }

  async getAllScenarios(): Promise<Scenario[]> {
    return Array.from(this.scenarios.values());
  }

  async createScenario(insertScenario: InsertScenario): Promise<Scenario> {
    const id = randomUUID();
    const scenario: Scenario = { ...insertScenario, id };
    this.scenarios.set(id, scenario);
    return scenario;
  }

  async logDecision(log: Omit<DecisionLog, "id" | "timestamp">): Promise<DecisionLog> {
    const id = randomUUID();
    const decisionLog: DecisionLog = {
      ...log,
      id,
      timestamp: new Date().toISOString(),
    };
    this.decisionLogs.set(id, decisionLog);
    return decisionLog;
  }

  async getDecisionLogs(sessionId: string): Promise<DecisionLog[]> {
    return Array.from(this.decisionLogs.values())
      .filter((log) => log.sessionId === sessionId)
      .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
  }

  async simulateRound(sessionId: string, roundIndex: number): Promise<KPI> {
    const session = await this.getSession(sessionId);
    if (!session) {
      throw new Error("Session not found");
    }

    const round = session.rounds[roundIndex];
    if (!round) {
      throw new Error("Round not found");
    }

    const kpi = this.calculateKPI(round);
    
    const updatedRounds = [...session.rounds];
    updatedRounds[roundIndex] = {
      ...round,
      kpiResults: kpi,
      phase: "reviewing",
      completedAt: new Date().toISOString(),
    };

    await this.updateSession(sessionId, { rounds: updatedRounds });

    return kpi;
  }

  private calculateKPI(round: Round): KPI {
    const { workstations } = round.configuration.productionLine;
    const { products } = round.configuration;
    const { leanInitiatives, automationSettings } = round.configuration;

    const stationCount = workstations.length || 1;
    
    let totalAvailability = 0;
    let totalPerformance = 0;
    let totalQuality = 0;
    let totalCycleTime = 0;

    const utilizationByStation: Record<string, number> = {};
    let bottleneckStation: string | null = null;
    let maxEffectiveCycleTime = 0;

    workstations.forEach((ws) => {
      totalAvailability += ws.availability;
      totalPerformance += ws.performance;
      totalQuality += ws.quality;
      totalCycleTime += ws.cycleTime;

      const effectiveCycleTime = ws.cycleTime / ws.machineCount;
      
      if (effectiveCycleTime > maxEffectiveCycleTime) {
        maxEffectiveCycleTime = effectiveCycleTime;
        bottleneckStation = ws.id;
      }

      const baseUtilization = 65 + (ws.performance / 100) * 25;
      utilizationByStation[ws.id] = Math.min(100, Math.max(40, baseUtilization));
    });

    let availability = totalAvailability / stationCount;
    let performance = totalPerformance / stationCount;
    let quality = totalQuality / stationCount;

    if (automationSettings.preventiveMaintenance) {
      availability = Math.min(100, availability + 5);
    }

    if (leanInitiatives.wipLimitsEnabled) {
      performance = Math.min(100, performance + 3);
    }

    if (leanInitiatives.qualityCheckpointsEnabled) {
      quality = Math.min(100, quality + 4);
    }

    if (leanInitiatives.layoutOptimized) {
      performance = Math.min(100, performance + 2);
    }

    const automationBonus = automationSettings.targetAutomationLevel === "fully_automated" ? 8 :
      automationSettings.targetAutomationLevel === "semi_automated" ? 4 : 0;
    performance = Math.min(100, performance + automationBonus);

    availability = Math.max(50, Math.min(100, availability));
    performance = Math.max(50, Math.min(100, performance));
    quality = Math.max(70, Math.min(100, quality));

    const oeeOverall = (availability / 100) * (performance / 100) * (quality / 100) * 100;

    const shiftSeconds = 8 * 3600;
    const bottleneckCapacity = shiftSeconds / maxEffectiveCycleTime;
    const throughput = Math.round(bottleneckCapacity * (oeeOverall / 100));

    const overallUtilization = Object.values(utilizationByStation).reduce((a, b) => a + b, 0) / stationCount;

    const defectRate = Math.max(0, (100 - quality) * 0.5);
    const reworkRate = defectRate * 0.4;

    const avgCycleTime = totalCycleTime / stationCount;
    const waitingTimeFactor = 1 + (100 - performance) / 200;
    const leadTime = avgCycleTime * stationCount * waitingTimeFactor;

    const mtsProducts = products.filter((p) => p.mode === "MTS");
    const mtoProducts = products.filter((p) => p.mode === "MTO");

    const inventory = mtsProducts.reduce((acc, p) => acc + p.safetyStock + Math.round(p.demandRate * 0.5), 0);
    
    const backlog = mtoProducts.reduce((acc, p) => Math.round(acc + p.demandRate * 0.2), 0);

    return {
      throughput,
      utilizationByStation,
      overallUtilization,
      oeeAvailability: availability,
      oeePerformance: performance,
      oeeQuality: quality,
      oeeOverall,
      defectRate,
      reworkRate,
      leadTime,
      inventory,
      backlog,
      bottleneckStation,
    };
  }
}

export const storage = new MemStorage();
