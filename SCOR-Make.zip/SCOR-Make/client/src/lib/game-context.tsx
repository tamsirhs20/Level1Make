import { createContext, useContext, useState, useCallback } from "react";
import { type GameSession, type Round, type TeamRole, type Workstation, type Product, type KPI } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

interface GameContextType {
  session: GameSession | null;
  setSession: (session: GameSession | null) => void;
  currentRound: Round | null;
  selectedRole: TeamRole | null;
  setSelectedRole: (role: TeamRole | null) => void;
  updateWorkstation: (stationId: string, updates: Partial<Workstation>) => void;
  updateProduct: (productId: string, updates: Partial<Product>) => void;
  updateLeanInitiatives: (updates: Partial<Round["configuration"]["leanInitiatives"]>) => void;
  updateAutomationSettings: (updates: Partial<Round["configuration"]["automationSettings"]>) => void;
  startSimulation: () => Promise<void>;
  advanceToNextRound: () => void;
  isSimulating: boolean;
  saveSession: () => Promise<void>;
}

const GameContext = createContext<GameContextType | undefined>(undefined);

export function GameProvider({ children }: { children: React.ReactNode }) {
  const [session, setSession] = useState<GameSession | null>(null);
  const [selectedRole, setSelectedRole] = useState<TeamRole | null>(null);
  const [isSimulating, setIsSimulating] = useState(false);

  const currentRound = session?.rounds[session.currentRoundIndex] ?? null;

  const updateWorkstation = useCallback((stationId: string, updates: Partial<Workstation>) => {
    setSession((prev) => {
      if (!prev) return prev;
      const newRounds = [...prev.rounds];
      const currentRoundIdx = prev.currentRoundIndex;
      const round = newRounds[currentRoundIdx];
      
      newRounds[currentRoundIdx] = {
        ...round,
        configuration: {
          ...round.configuration,
          productionLine: {
            ...round.configuration.productionLine,
            workstations: round.configuration.productionLine.workstations.map((ws) =>
              ws.id === stationId ? { ...ws, ...updates } : ws
            ),
          },
        },
      };

      return { ...prev, rounds: newRounds };
    });
  }, []);

  const updateProduct = useCallback((productId: string, updates: Partial<Product>) => {
    setSession((prev) => {
      if (!prev) return prev;
      const newRounds = [...prev.rounds];
      const currentRoundIdx = prev.currentRoundIndex;
      const round = newRounds[currentRoundIdx];

      newRounds[currentRoundIdx] = {
        ...round,
        configuration: {
          ...round.configuration,
          products: round.configuration.products.map((p) =>
            p.id === productId ? { ...p, ...updates } : p
          ),
        },
      };

      return { ...prev, rounds: newRounds };
    });
  }, []);

  const updateLeanInitiatives = useCallback((updates: Partial<Round["configuration"]["leanInitiatives"]>) => {
    setSession((prev) => {
      if (!prev) return prev;
      const newRounds = [...prev.rounds];
      const currentRoundIdx = prev.currentRoundIndex;
      const round = newRounds[currentRoundIdx];

      newRounds[currentRoundIdx] = {
        ...round,
        configuration: {
          ...round.configuration,
          leanInitiatives: {
            ...round.configuration.leanInitiatives,
            ...updates,
          },
        },
      };

      return { ...prev, rounds: newRounds };
    });
  }, []);

  const updateAutomationSettings = useCallback((updates: Partial<Round["configuration"]["automationSettings"]>) => {
    setSession((prev) => {
      if (!prev) return prev;
      const newRounds = [...prev.rounds];
      const currentRoundIdx = prev.currentRoundIndex;
      const round = newRounds[currentRoundIdx];

      newRounds[currentRoundIdx] = {
        ...round,
        configuration: {
          ...round.configuration,
          automationSettings: {
            ...round.configuration.automationSettings,
            ...updates,
          },
        },
      };

      return { ...prev, rounds: newRounds };
    });
  }, []);

  const saveSession = useCallback(async () => {
    if (!session) return;
    
    try {
      await apiRequest("PATCH", `/api/sessions/${session.id}`, session);
    } catch (error) {
      console.error("Failed to save session:", error);
    }
  }, [session]);

  const startSimulation = useCallback(async () => {
    if (!session) return;

    setIsSimulating(true);

    try {
      await saveSession();

      const response = await apiRequest("POST", `/api/sessions/${session.id}/simulate`, {
        roundIndex: session.currentRoundIndex,
      });
      const kpiResults = await response.json() as KPI;

      setSession((prev) => {
        if (!prev) return prev;
        const newRounds = [...prev.rounds];
        const currentRoundIdx = prev.currentRoundIndex;
        const round = newRounds[currentRoundIdx];

        newRounds[currentRoundIdx] = {
          ...round,
          phase: "reviewing",
          kpiResults,
          completedAt: new Date().toISOString(),
        };

        return { ...prev, rounds: newRounds };
      });
    } catch (error) {
      console.error("Simulation failed:", error);
      
      const kpiResults = simulateRoundLocally(session.rounds[session.currentRoundIndex]);
      
      setSession((prev) => {
        if (!prev) return prev;
        const newRounds = [...prev.rounds];
        const currentRoundIdx = prev.currentRoundIndex;
        const round = newRounds[currentRoundIdx];

        newRounds[currentRoundIdx] = {
          ...round,
          phase: "reviewing",
          kpiResults,
          completedAt: new Date().toISOString(),
        };

        return { ...prev, rounds: newRounds };
      });
    } finally {
      setIsSimulating(false);
    }
  }, [session, saveSession]);

  const advanceToNextRound = useCallback(() => {
    setSession((prev) => {
      if (!prev) return prev;
      
      if (prev.currentRoundIndex < prev.rounds.length - 1) {
        return { ...prev, currentRoundIndex: prev.currentRoundIndex + 1 };
      }
      
      return prev;
    });
  }, []);

  return (
    <GameContext.Provider
      value={{
        session,
        setSession,
        currentRound,
        selectedRole,
        setSelectedRole,
        updateWorkstation,
        updateProduct,
        updateLeanInitiatives,
        updateAutomationSettings,
        startSimulation,
        advanceToNextRound,
        isSimulating,
        saveSession,
      }}
    >
      {children}
    </GameContext.Provider>
  );
}

export function useGame() {
  const context = useContext(GameContext);
  if (!context) {
    throw new Error("useGame must be used within a GameProvider");
  }
  return context;
}

function simulateRoundLocally(round: Round): KPI {
  const { workstations } = round.configuration.productionLine;
  const { products } = round.configuration;
  const { leanInitiatives, automationSettings } = round.configuration;

  const stationCount = workstations.length || 1;
  
  let totalAvailability = 0;
  let totalPerformance = 0;
  let totalQuality = 0;
  let totalCycleTime = 0;
  let totalCapacity = 0;

  const utilizationByStation: Record<string, number> = {};
  let bottleneckStation: string | null = null;
  let maxEffectiveCycleTime = 0;

  workstations.forEach((ws) => {
    totalAvailability += ws.availability;
    totalPerformance += ws.performance;
    totalQuality += ws.quality;
    totalCycleTime += ws.cycleTime;

    const effectiveCycleTime = ws.cycleTime / ws.machineCount;
    const stationCapacity = (8 * 3600) / effectiveCycleTime;
    totalCapacity += stationCapacity;

    if (effectiveCycleTime > maxEffectiveCycleTime) {
      maxEffectiveCycleTime = effectiveCycleTime;
      bottleneckStation = ws.id;
    }

    const baseUtilization = 65 + (ws.performance / 100) * 25;
    utilizationByStation[ws.id] = Math.min(100, Math.max(40, baseUtilization));
  });

  let availability = totalAvailability / stationCount;
  let performance = totalPerformance / stationCount;
  let quality = totalQuality / stationCount;

  if (automationSettings.preventiveMaintenance) {
    availability = Math.min(100, availability + 5);
  }

  if (leanInitiatives.wipLimitsEnabled) {
    performance = Math.min(100, performance + 3);
  }

  if (leanInitiatives.qualityCheckpointsEnabled) {
    quality = Math.min(100, quality + 4);
  }

  if (leanInitiatives.layoutOptimized) {
    performance = Math.min(100, performance + 2);
  }

  const automationBonus = automationSettings.targetAutomationLevel === "fully_automated" ? 8 :
    automationSettings.targetAutomationLevel === "semi_automated" ? 4 : 0;
  performance = Math.min(100, performance + automationBonus);

  availability = Math.max(50, Math.min(100, availability));
  performance = Math.max(50, Math.min(100, performance));
  quality = Math.max(70, Math.min(100, quality));

  const oeeOverall = (availability / 100) * (performance / 100) * (quality / 100) * 100;

  const bottleneckCapacity = (8 * 3600) / maxEffectiveCycleTime;
  const throughput = Math.round(bottleneckCapacity * (oeeOverall / 100));

  const overallUtilization = Object.values(utilizationByStation).reduce((a, b) => a + b, 0) / stationCount;

  const defectRate = Math.max(0, (100 - quality) * 0.5);
  const reworkRate = defectRate * 0.4;

  const avgCycleTime = totalCycleTime / stationCount;
  const waitingTimeFactor = 1 + (100 - performance) / 200;
  const leadTime = avgCycleTime * stationCount * waitingTimeFactor;

  const mtsProducts = products.filter((p) => p.mode === "MTS");
  const mtoProducts = products.filter((p) => p.mode === "MTO");

  const inventory = mtsProducts.reduce((acc, p) => acc + p.safetyStock + Math.round(p.demandRate * 0.5), 0);
  
  const backlog = mtoProducts.reduce((acc, p) => Math.round(acc + p.demandRate * 0.2), 0);

  return {
    throughput,
    utilizationByStation,
    overallUtilization,
    oeeAvailability: availability,
    oeePerformance: performance,
    oeeQuality: quality,
    oeeOverall,
    defectRate,
    reworkRate,
    leadTime,
    inventory,
    backlog,
    bottleneckStation,
  };
}
