import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { cn } from "@/lib/utils";

interface OEEDashboardProps {
  availability: number;
  performance: number;
  quality: number;
  className?: string;
}

export function OEEDashboard({
  availability,
  performance,
  quality,
  className,
}: OEEDashboardProps) {
  const oeeOverall = (availability / 100) * (performance / 100) * (quality / 100) * 100;

  const getOEEColor = (value: number) => {
    if (value >= 85) return "text-chart-3";
    if (value >= 60) return "text-chart-2";
    return "text-destructive";
  };

  const getProgressColor = (value: number) => {
    if (value >= 85) return "bg-chart-3";
    if (value >= 60) return "bg-chart-2";
    return "bg-destructive";
  };

  return (
    <Card className={cn("", className)} data-testid="oee-dashboard">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg flex items-center justify-between gap-2">
          <span>Overall Equipment Effectiveness</span>
          <span className={cn("font-mono text-3xl", getOEEColor(oeeOverall))} data-testid="oee-overall-value">
            {oeeOverall.toFixed(1)}%
          </span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <div className="flex items-center justify-between gap-2">
            <span className="text-sm text-muted-foreground">Availability (A)</span>
            <span className="font-mono text-sm" data-testid="oee-availability">{availability.toFixed(1)}%</span>
          </div>
          <div className="relative h-3 w-full overflow-hidden rounded-full bg-muted">
            <div
              className={cn("h-full transition-all duration-500", getProgressColor(availability))}
              style={{ width: `${availability}%` }}
            />
          </div>
        </div>

        <div className="space-y-2">
          <div className="flex items-center justify-between gap-2">
            <span className="text-sm text-muted-foreground">Performance (P)</span>
            <span className="font-mono text-sm" data-testid="oee-performance">{performance.toFixed(1)}%</span>
          </div>
          <div className="relative h-3 w-full overflow-hidden rounded-full bg-muted">
            <div
              className={cn("h-full transition-all duration-500", getProgressColor(performance))}
              style={{ width: `${performance}%` }}
            />
          </div>
        </div>

        <div className="space-y-2">
          <div className="flex items-center justify-between gap-2">
            <span className="text-sm text-muted-foreground">Quality (Q)</span>
            <span className="font-mono text-sm" data-testid="oee-quality">{quality.toFixed(1)}%</span>
          </div>
          <div className="relative h-3 w-full overflow-hidden rounded-full bg-muted">
            <div
              className={cn("h-full transition-all duration-500", getProgressColor(quality))}
              style={{ width: `${quality}%` }}
            />
          </div>
        </div>

        <div className="pt-2 border-t">
          <div className="text-xs text-muted-foreground">
            OEE = A × P × Q = {availability.toFixed(1)}% × {performance.toFixed(1)}% × {quality.toFixed(1)}% = <span className="font-semibold">{oeeOverall.toFixed(1)}%</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
