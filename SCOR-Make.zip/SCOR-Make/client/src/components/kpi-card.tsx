import { Card, CardContent } from "@/components/ui/card";
import { TrendingUp, TrendingDown, Minus } from "lucide-react";
import { cn } from "@/lib/utils";

interface KPICardProps {
  label: string;
  value: string | number;
  unit?: string;
  trend?: number;
  target?: number;
  className?: string;
  variant?: "default" | "success" | "warning" | "danger";
}

export function KPICard({
  label,
  value,
  unit = "",
  trend,
  target,
  className,
  variant = "default",
}: KPICardProps) {
  const getTrendIcon = () => {
    if (trend === undefined || trend === 0) return <Minus className="h-4 w-4" />;
    if (trend > 0) return <TrendingUp className="h-4 w-4" />;
    return <TrendingDown className="h-4 w-4" />;
  };

  const getTrendColor = () => {
    if (trend === undefined || trend === 0) return "text-muted-foreground";
    if (trend > 0) return "text-chart-3";
    return "text-destructive";
  };

  const getVariantStyles = () => {
    switch (variant) {
      case "success":
        return "border-l-4 border-l-chart-3";
      case "warning":
        return "border-l-4 border-l-chart-2";
      case "danger":
        return "border-l-4 border-l-destructive";
      default:
        return "";
    }
  };

  return (
    <Card className={cn("min-h-32", getVariantStyles(), className)} data-testid={`kpi-card-${label.toLowerCase().replace(/\s+/g, "-")}`}>
      <CardContent className="p-4 flex flex-col justify-between h-full">
        <div className="flex items-center justify-between gap-2">
          <span className="text-sm text-muted-foreground">{label}</span>
          {trend !== undefined && (
            <span className={cn("flex items-center gap-1 text-sm", getTrendColor())}>
              {getTrendIcon()}
              <span className="font-mono">{Math.abs(trend).toFixed(1)}%</span>
            </span>
          )}
        </div>
        <div className="mt-2">
          <span className="text-3xl font-mono font-semibold" data-testid={`kpi-value-${label.toLowerCase().replace(/\s+/g, "-")}`}>
            {typeof value === "number" ? value.toLocaleString() : value}
          </span>
          {unit && <span className="text-lg text-muted-foreground ml-1">{unit}</span>}
        </div>
        {target !== undefined && (
          <div className="mt-2 text-xs text-muted-foreground">
            Target: <span className="font-mono">{target}{unit}</span>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
