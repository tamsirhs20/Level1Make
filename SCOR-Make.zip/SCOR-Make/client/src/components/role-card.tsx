import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { type TeamRole, type RoleConfig } from "@shared/schema";
import { ClipboardList, Settings, Shield, Cpu, BarChart3, LucideIcon } from "lucide-react";

interface RoleCardProps {
  role: RoleConfig;
  isActive?: boolean;
  isSelected?: boolean;
  memberName?: string;
  onClick?: () => void;
  className?: string;
}

const iconMap: Record<string, LucideIcon> = {
  ClipboardList,
  Settings,
  Shield,
  Cpu,
  BarChart3,
};

export function RoleCard({
  role,
  isActive = false,
  isSelected = false,
  memberName,
  onClick,
  className,
}: RoleCardProps) {
  const Icon = iconMap[role.icon] || ClipboardList;

  return (
    <Card
      className={cn(
        "transition-all cursor-pointer hover-elevate",
        isSelected && "ring-2 ring-primary ring-offset-2",
        isActive && "border-chart-3",
        className
      )}
      onClick={onClick}
      data-testid={`role-card-${role.id}`}
    >
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between gap-2">
          <div className={cn("p-2 rounded-md", `bg-${role.color}/20`)}>
            <Icon className={cn("h-5 w-5", `text-${role.color}`)} />
          </div>
          {isActive && (
            <Badge variant="outline" className="text-xs">
              Active
            </Badge>
          )}
        </div>
        <CardTitle className="text-base mt-2">{role.name}</CardTitle>
      </CardHeader>
      <CardContent>
        <p className="text-sm text-muted-foreground line-clamp-2">
          {role.description}
        </p>
        {memberName && (
          <div className="mt-3 pt-3 border-t">
            <span className="text-xs text-muted-foreground">Assigned to: </span>
            <span className="text-xs font-medium">{memberName}</span>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
