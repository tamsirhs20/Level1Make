import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useGame } from "@/lib/game-context";
import { type AutomationLevel } from "@shared/schema";
import { Cpu, Wrench, Cog, Zap, Calendar } from "lucide-react";

export function AutomationEngineerModule() {
  const { currentRound, updateAutomationSettings, updateWorkstation } = useGame();

  if (!currentRound) return null;

  const { automationSettings } = currentRound.configuration;
  const { workstations } = currentRound.configuration.productionLine;

  const automationCounts = {
    manual: workstations.filter((ws) => ws.automationLevel === "manual").length,
    semi_automated: workstations.filter((ws) => ws.automationLevel === "semi_automated").length,
    fully_automated: workstations.filter((ws) => ws.automationLevel === "fully_automated").length,
  };

  const avgAvailability = workstations.reduce((acc, ws) => acc + ws.availability, 0) / workstations.length;

  const getAutomationIcon = (level: AutomationLevel) => {
    switch (level) {
      case "manual":
        return <Wrench className="h-4 w-4" />;
      case "semi_automated":
        return <Cog className="h-4 w-4" />;
      case "fully_automated":
        return <Zap className="h-4 w-4" />;
    }
  };

  return (
    <Card className="h-full" data-testid="module-automation-engineer">
      <CardHeader className="pb-4">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-md bg-chart-4/20">
            <Cpu className="h-5 w-5 text-chart-4" />
          </div>
          <div>
            <CardTitle className="text-lg">Automation & Maintenance</CardTitle>
            <p className="text-sm text-muted-foreground mt-1">
              Configure automation levels and maintenance schedules
            </p>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="p-3 bg-muted/50 rounded-lg text-center">
            <span className="text-2xl font-mono font-semibold" data-testid="text-manual-count">
              {automationCounts.manual}
            </span>
            <p className="text-xs text-muted-foreground mt-1 flex items-center justify-center gap-1">
              <Wrench className="h-3 w-3" /> Manual
            </p>
          </div>
          <div className="p-3 bg-muted/50 rounded-lg text-center">
            <span className="text-2xl font-mono font-semibold" data-testid="text-semi-count">
              {automationCounts.semi_automated}
            </span>
            <p className="text-xs text-muted-foreground mt-1 flex items-center justify-center gap-1">
              <Cog className="h-3 w-3" /> Semi-Auto
            </p>
          </div>
          <div className="p-3 bg-muted/50 rounded-lg text-center">
            <span className="text-2xl font-mono font-semibold" data-testid="text-full-count">
              {automationCounts.fully_automated}
            </span>
            <p className="text-xs text-muted-foreground mt-1 flex items-center justify-center gap-1">
              <Zap className="h-3 w-3" /> Fully Auto
            </p>
          </div>
          <div className="p-3 bg-muted/50 rounded-lg text-center">
            <span className="text-2xl font-mono font-semibold text-chart-3" data-testid="text-availability">
              {avgAvailability.toFixed(1)}%
            </span>
            <p className="text-xs text-muted-foreground mt-1">Availability</p>
          </div>
        </div>

        <div className="space-y-4">
          <h4 className="text-sm font-medium">Global Settings</h4>
          
          <div className="p-4 border rounded-lg space-y-4">
            <div className="space-y-2">
              <Label className="text-sm">Target Automation Level</Label>
              <RadioGroup
                value={automationSettings.targetAutomationLevel}
                onValueChange={(value) =>
                  updateAutomationSettings({ targetAutomationLevel: value as AutomationLevel })
                }
                className="flex flex-wrap gap-4"
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="manual" id="target-manual" data-testid="radio-manual" />
                  <Label htmlFor="target-manual" className="flex items-center gap-1 cursor-pointer">
                    <Wrench className="h-4 w-4" /> Manual
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="semi_automated" id="target-semi" data-testid="radio-semi" />
                  <Label htmlFor="target-semi" className="flex items-center gap-1 cursor-pointer">
                    <Cog className="h-4 w-4" /> Semi-Auto
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="fully_automated" id="target-full" data-testid="radio-full" />
                  <Label htmlFor="target-full" className="flex items-center gap-1 cursor-pointer">
                    <Zap className="h-4 w-4" /> Fully Auto
                  </Label>
                </div>
              </RadioGroup>
            </div>

            <div className="flex items-center justify-between">
              <div>
                <span className="font-medium">Preventive Maintenance</span>
                <p className="text-xs text-muted-foreground mt-1">
                  Schedule regular maintenance to improve availability
                </p>
              </div>
              <Switch
                checked={automationSettings.preventiveMaintenance}
                onCheckedChange={(checked) =>
                  updateAutomationSettings({ preventiveMaintenance: checked })
                }
                data-testid="switch-preventive-maintenance"
              />
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <h4 className="text-sm font-medium">Station Automation</h4>
          
          {workstations.map((station) => (
            <div
              key={station.id}
              className="p-4 border rounded-lg space-y-3"
              data-testid={`automation-station-${station.id}`}
            >
              <div className="flex items-center justify-between gap-2 flex-wrap">
                <div className="flex items-center gap-2">
                  {getAutomationIcon(station.automationLevel)}
                  <span className="font-medium">{station.name}</span>
                </div>
                <Badge variant="outline">
                  Availability: {station.availability}%
                </Badge>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-sm">Automation Level</Label>
                  <Select
                    value={station.automationLevel}
                    onValueChange={(value) =>
                      updateWorkstation(station.id, { automationLevel: value as AutomationLevel })
                    }
                  >
                    <SelectTrigger data-testid={`select-automation-${station.id}`}>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="manual">
                        <span className="flex items-center gap-2">
                          <Wrench className="h-4 w-4" /> Manual
                        </span>
                      </SelectItem>
                      <SelectItem value="semi_automated">
                        <span className="flex items-center gap-2">
                          <Cog className="h-4 w-4" /> Semi-Auto
                        </span>
                      </SelectItem>
                      <SelectItem value="fully_automated">
                        <span className="flex items-center gap-2">
                          <Zap className="h-4 w-4" /> Fully Auto
                        </span>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label className="text-sm flex items-center gap-1">
                    <Calendar className="h-3 w-3" /> Maintenance Schedule
                  </Label>
                  <Select
                    value={station.maintenanceSchedule}
                    onValueChange={(value) =>
                      updateWorkstation(station.id, { maintenanceSchedule: value as "none" | "weekly" | "daily" })
                    }
                  >
                    <SelectTrigger data-testid={`select-maintenance-${station.id}`}>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">No Schedule</SelectItem>
                      <SelectItem value="weekly">Weekly</SelectItem>
                      <SelectItem value="daily">Daily</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="p-4 bg-muted/50 rounded-lg">
          <h4 className="text-sm font-medium mb-2">Automation Tips</h4>
          <ul className="text-xs text-muted-foreground space-y-1">
            <li>Higher automation reduces cycle time but increases breakdown risk.</li>
            <li>Preventive maintenance improves availability (A in OEE).</li>
            <li>Balance automation costs vs productivity gains.</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );
}
