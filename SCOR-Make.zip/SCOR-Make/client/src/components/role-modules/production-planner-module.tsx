import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Slider } from "@/components/ui/slider";
import { useGame } from "@/lib/game-context";
import { ClipboardList } from "lucide-react";

export function ProductionPlannerModule() {
  const { currentRound, updateProduct } = useGame();

  if (!currentRound) return null;

  const { products } = currentRound.configuration;

  return (
    <Card className="h-full" data-testid="module-production-planner">
      <CardHeader className="pb-4">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-md bg-chart-1/20">
            <ClipboardList className="h-5 w-5 text-chart-1" />
          </div>
          <div>
            <CardTitle className="text-lg">Production Planner</CardTitle>
            <p className="text-sm text-muted-foreground mt-1">
              Configure MTS/MTO strategy, lot sizes, and priorities
            </p>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {products.map((product) => (
          <div
            key={product.id}
            className="p-4 border rounded-lg space-y-4"
            data-testid={`product-config-${product.id}`}
          >
            <div className="flex items-center justify-between gap-2 flex-wrap">
              <div className="flex items-center gap-2">
                <span className="font-medium">{product.name}</span>
                <Badge variant={product.mode === "MTS" ? "default" : "secondary"}>
                  {product.mode}
                </Badge>
              </div>
              <div className="flex items-center gap-2">
                <Label htmlFor={`mode-${product.id}`} className="text-sm">
                  MTO
                </Label>
                <Switch
                  id={`mode-${product.id}`}
                  checked={product.mode === "MTS"}
                  onCheckedChange={(checked) =>
                    updateProduct(product.id, { mode: checked ? "MTS" : "MTO" })
                  }
                  data-testid={`switch-mode-${product.id}`}
                />
                <Label htmlFor={`mode-${product.id}`} className="text-sm">
                  MTS
                </Label>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor={`lot-${product.id}`} className="text-sm">
                  Lot Size
                </Label>
                <Input
                  id={`lot-${product.id}`}
                  type="number"
                  min={1}
                  max={1000}
                  value={product.lotSize}
                  onChange={(e) =>
                    updateProduct(product.id, { lotSize: parseInt(e.target.value) || 1 })
                  }
                  className="font-mono"
                  data-testid={`input-lot-${product.id}`}
                />
                <p className="text-xs text-muted-foreground">Units per batch</p>
              </div>

              {product.mode === "MTS" && (
                <div className="space-y-2">
                  <Label htmlFor={`safety-${product.id}`} className="text-sm">
                    Safety Stock
                  </Label>
                  <Input
                    id={`safety-${product.id}`}
                    type="number"
                    min={0}
                    max={500}
                    value={product.safetyStock}
                    onChange={(e) =>
                      updateProduct(product.id, { safetyStock: parseInt(e.target.value) || 0 })
                    }
                    className="font-mono"
                    data-testid={`input-safety-${product.id}`}
                  />
                  <p className="text-xs text-muted-foreground">Minimum inventory level</p>
                </div>
              )}
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label className="text-sm">Demand Rate</Label>
                <span className="text-sm font-mono text-muted-foreground">
                  {product.demandRate} units/day
                </span>
              </div>
              <Slider
                value={[product.demandRate]}
                onValueChange={([value]) => updateProduct(product.id, { demandRate: value })}
                min={10}
                max={200}
                step={5}
                className="w-full"
                data-testid={`slider-demand-${product.id}`}
              />
            </div>
          </div>
        ))}

        <div className="p-4 bg-muted/50 rounded-lg">
          <h4 className="text-sm font-medium mb-2">Strategy Tips</h4>
          <ul className="text-xs text-muted-foreground space-y-1">
            <li>MTS: Best for stable, predictable demand. Builds inventory.</li>
            <li>MTO: Best for variable demand. Reduces inventory but increases lead time.</li>
            <li>Larger lot sizes reduce setup time but increase inventory.</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );
}
