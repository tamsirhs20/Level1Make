import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useGame } from "@/lib/game-context";
import { Shield, CheckCircle, AlertCircle } from "lucide-react";

export function LeanQualityModule() {
  const { currentRound, updateLeanInitiatives, updateWorkstation } = useGame();

  if (!currentRound) return null;

  const { leanInitiatives } = currentRound.configuration;
  const { workstations } = currentRound.configuration.productionLine;

  const qualityCheckpoints = workstations.filter((ws) => ws.qualityCheckpoint);
  const avgQuality = workstations.reduce((acc, ws) => acc + ws.quality, 0) / workstations.length;

  return (
    <Card className="h-full" data-testid="module-lean-quality">
      <CardHeader className="pb-4">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-md bg-chart-3/20">
            <Shield className="h-5 w-5 text-chart-3" />
          </div>
          <div>
            <CardTitle className="text-lg">Lean & Quality</CardTitle>
            <p className="text-sm text-muted-foreground mt-1">
              Apply lean principles and improve quality control
            </p>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          <div className="p-3 bg-muted/50 rounded-lg text-center">
            <span className="text-2xl font-mono font-semibold text-chart-3" data-testid="text-quality-score">
              {avgQuality.toFixed(1)}%
            </span>
            <p className="text-xs text-muted-foreground mt-1">Avg Quality</p>
          </div>
          <div className="p-3 bg-muted/50 rounded-lg text-center">
            <span className="text-2xl font-mono font-semibold" data-testid="text-checkpoints">
              {qualityCheckpoints.length}
            </span>
            <p className="text-xs text-muted-foreground mt-1">Checkpoints</p>
          </div>
          <div className="p-3 bg-muted/50 rounded-lg text-center">
            <span className="text-2xl font-mono font-semibold">
              {workstations.filter((ws) => ws.wipLimit !== null).length}
            </span>
            <p className="text-xs text-muted-foreground mt-1">WIP Limits</p>
          </div>
        </div>

        <div className="space-y-4">
          <h4 className="text-sm font-medium">Lean Initiatives</h4>
          
          <div className="flex items-center justify-between p-4 border rounded-lg">
            <div>
              <span className="font-medium">WIP Limits</span>
              <p className="text-xs text-muted-foreground mt-1">
                Limit work-in-progress to reduce waiting time
              </p>
            </div>
            <Switch
              checked={leanInitiatives.wipLimitsEnabled}
              onCheckedChange={(checked) =>
                updateLeanInitiatives({ wipLimitsEnabled: checked })
              }
              data-testid="switch-wip-limits"
            />
          </div>

          <div className="flex items-center justify-between p-4 border rounded-lg">
            <div>
              <span className="font-medium">Quality Checkpoints</span>
              <p className="text-xs text-muted-foreground mt-1">
                Add inspection points to catch defects early
              </p>
            </div>
            <Switch
              checked={leanInitiatives.qualityCheckpointsEnabled}
              onCheckedChange={(checked) =>
                updateLeanInitiatives({ qualityCheckpointsEnabled: checked })
              }
              data-testid="switch-quality-checkpoints"
            />
          </div>

          <div className="flex items-center justify-between p-4 border rounded-lg">
            <div>
              <span className="font-medium">Layout Optimization</span>
              <p className="text-xs text-muted-foreground mt-1">
                Optimize station layout to reduce transport waste
              </p>
            </div>
            <Switch
              checked={leanInitiatives.layoutOptimized}
              onCheckedChange={(checked) =>
                updateLeanInitiatives({ layoutOptimized: checked })
              }
              data-testid="switch-layout-optimization"
            />
          </div>
        </div>

        <div className="space-y-4">
          <h4 className="text-sm font-medium">Station Quality Settings</h4>
          
          {workstations.map((station) => (
            <div
              key={station.id}
              className="p-4 border rounded-lg space-y-3"
              data-testid={`quality-station-${station.id}`}
            >
              <div className="flex items-center justify-between gap-2 flex-wrap">
                <div className="flex items-center gap-2">
                  <span className="font-medium">{station.name}</span>
                  {station.qualityCheckpoint && (
                    <Badge variant="outline" className="gap-1 text-chart-3 border-chart-3">
                      <CheckCircle className="h-3 w-3" />
                      Checkpoint
                    </Badge>
                  )}
                </div>
                <span className="text-sm font-mono">
                  Quality: {station.quality}%
                </span>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-center justify-between">
                  <Label className="text-sm">Quality Checkpoint</Label>
                  <Switch
                    checked={station.qualityCheckpoint}
                    onCheckedChange={(checked) =>
                      updateWorkstation(station.id, { qualityCheckpoint: checked })
                    }
                    data-testid={`switch-checkpoint-${station.id}`}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor={`wip-${station.id}`} className="text-sm">
                    WIP Limit
                  </Label>
                  <Input
                    id={`wip-${station.id}`}
                    type="number"
                    min={0}
                    max={100}
                    value={station.wipLimit ?? ""}
                    placeholder="No limit"
                    onChange={(e) =>
                      updateWorkstation(station.id, {
                        wipLimit: e.target.value ? parseInt(e.target.value) : null,
                      })
                    }
                    className="font-mono"
                    data-testid={`input-wip-${station.id}`}
                  />
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="p-4 bg-muted/50 rounded-lg">
          <h4 className="text-sm font-medium mb-2">Lean & Quality Tips</h4>
          <ul className="text-xs text-muted-foreground space-y-1">
            <li>Quality checkpoints catch defects early, reducing rework costs.</li>
            <li>WIP limits prevent overproduction and reduce waiting time.</li>
            <li>Layout optimization reduces transport waste between stations.</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );
}
