import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";
import { useGame } from "@/lib/game-context";
import { Settings, AlertTriangle } from "lucide-react";

export function CapacityEngineerModule() {
  const { currentRound, updateWorkstation } = useGame();

  if (!currentRound) return null;

  const { workstations } = currentRound.configuration.productionLine;
  const sortedStations = [...workstations].sort((a, b) => a.position - b.position);

  const totalCycleTime = workstations.reduce((acc, ws) => acc + ws.cycleTime, 0);
  const avgCycleTime = totalCycleTime / workstations.length;
  
  const bottleneck = workstations.reduce((max, ws) => 
    (ws.cycleTime / ws.machineCount) > (max.cycleTime / max.machineCount) ? ws : max
  , workstations[0]);

  return (
    <Card className="h-full" data-testid="module-capacity-engineer">
      <CardHeader className="pb-4">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-md bg-chart-2/20">
            <Settings className="h-5 w-5 text-chart-2" />
          </div>
          <div>
            <CardTitle className="text-lg">Capacity & Line Balancing</CardTitle>
            <p className="text-sm text-muted-foreground mt-1">
              Design workstations and balance the production line
            </p>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="p-3 bg-muted/50 rounded-lg text-center">
            <span className="text-2xl font-mono font-semibold" data-testid="text-station-count">
              {workstations.length}
            </span>
            <p className="text-xs text-muted-foreground mt-1">Stations</p>
          </div>
          <div className="p-3 bg-muted/50 rounded-lg text-center">
            <span className="text-2xl font-mono font-semibold" data-testid="text-total-cycle">
              {totalCycleTime}s
            </span>
            <p className="text-xs text-muted-foreground mt-1">Total Cycle</p>
          </div>
          <div className="p-3 bg-muted/50 rounded-lg text-center">
            <span className="text-2xl font-mono font-semibold">
              {avgCycleTime.toFixed(1)}s
            </span>
            <p className="text-xs text-muted-foreground mt-1">Avg Cycle</p>
          </div>
          <div className="p-3 bg-destructive/10 rounded-lg text-center">
            <span className="text-sm font-medium text-destructive" data-testid="text-bottleneck">
              {bottleneck?.name}
            </span>
            <p className="text-xs text-muted-foreground mt-1">Bottleneck</p>
          </div>
        </div>

        <div className="space-y-4">
          {sortedStations.map((station) => {
            const isBottleneck = station.id === bottleneck?.id;
            const effectiveCycleTime = station.cycleTime / station.machineCount;

            return (
              <div
                key={station.id}
                className={`p-4 border rounded-lg space-y-4 ${isBottleneck ? "border-destructive bg-destructive/5" : ""}`}
                data-testid={`station-config-${station.id}`}
              >
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <div className="flex items-center gap-2">
                    <span className="font-medium">{station.name}</span>
                    {isBottleneck && (
                      <Badge variant="destructive" className="gap-1">
                        <AlertTriangle className="h-3 w-3" />
                        Bottleneck
                      </Badge>
                    )}
                  </div>
                  <span className="text-sm font-mono text-muted-foreground">
                    Position {station.position}
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label className="text-sm">Cycle Time</Label>
                      <span className="text-sm font-mono">{station.cycleTime}s</span>
                    </div>
                    <Slider
                      value={[station.cycleTime]}
                      onValueChange={([value]) =>
                        updateWorkstation(station.id, { cycleTime: value })
                      }
                      min={5}
                      max={120}
                      step={5}
                      data-testid={`slider-cycle-${station.id}`}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor={`machines-${station.id}`} className="text-sm">
                      Machines
                    </Label>
                    <Input
                      id={`machines-${station.id}`}
                      type="number"
                      min={1}
                      max={10}
                      value={station.machineCount}
                      onChange={(e) =>
                        updateWorkstation(station.id, {
                          machineCount: parseInt(e.target.value) || 1,
                        })
                      }
                      className="font-mono"
                      data-testid={`input-machines-${station.id}`}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor={`operators-${station.id}`} className="text-sm">
                      Operators
                    </Label>
                    <Input
                      id={`operators-${station.id}`}
                      type="number"
                      min={1}
                      max={10}
                      value={station.operatorCount}
                      onChange={(e) =>
                        updateWorkstation(station.id, {
                          operatorCount: parseInt(e.target.value) || 1,
                        })
                      }
                      className="font-mono"
                      data-testid={`input-operators-${station.id}`}
                    />
                  </div>
                </div>

                <div className="flex items-center justify-between text-xs text-muted-foreground pt-2 border-t">
                  <span>Effective Cycle Time: <span className="font-mono">{effectiveCycleTime.toFixed(1)}s</span></span>
                  <span>Capacity: <span className="font-mono">{Math.round(3600 / effectiveCycleTime)} units/hr</span></span>
                </div>
              </div>
            );
          })}
        </div>

        <div className="p-4 bg-muted/50 rounded-lg">
          <h4 className="text-sm font-medium mb-2">Line Balancing Tips</h4>
          <ul className="text-xs text-muted-foreground space-y-1">
            <li>Balance cycle times across stations to minimize bottlenecks.</li>
            <li>Add machines to bottleneck stations to increase capacity.</li>
            <li>Target similar effective cycle times for smooth flow.</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );
}
