import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { type RoundType, ROUND_TYPE_CONFIGS } from "@shared/schema";
import { CheckCircle, Circle, PlayCircle, Lock } from "lucide-react";

interface RoundProgressProps {
  currentRound: number;
  totalRounds: number;
  roundTypes: RoundType[];
  completedRounds: number[];
  className?: string;
}

export function RoundProgress({
  currentRound,
  totalRounds,
  roundTypes,
  completedRounds,
  className,
}: RoundProgressProps) {
  const getRoundIcon = (index: number) => {
    if (completedRounds.includes(index)) {
      return <CheckCircle className="h-5 w-5 text-chart-3" />;
    }
    if (index === currentRound) {
      return <PlayCircle className="h-5 w-5 text-primary" />;
    }
    if (index > currentRound) {
      return <Lock className="h-4 w-4 text-muted-foreground" />;
    }
    return <Circle className="h-5 w-5 text-muted-foreground" />;
  };

  return (
    <Card className={cn("", className)} data-testid="round-progress">
      <CardContent className="py-4">
        <div className="flex items-center justify-between gap-2 overflow-x-auto">
          {roundTypes.map((roundType, index) => (
            <div key={index} className="flex items-center gap-2 flex-shrink-0">
              <div
                className={cn(
                  "flex flex-col items-center gap-2 p-3 rounded-lg transition-all",
                  index === currentRound && "bg-primary/10",
                  completedRounds.includes(index) && "opacity-60"
                )}
              >
                {getRoundIcon(index)}
                <div className="text-center">
                  <div className="text-xs font-medium">
                    {ROUND_TYPE_CONFIGS[roundType].name}
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {ROUND_TYPE_CONFIGS[roundType].duration} min
                  </div>
                </div>
              </div>
              {index < roundTypes.length - 1 && (
                <div
                  className={cn(
                    "w-8 h-0.5",
                    completedRounds.includes(index) ? "bg-chart-3" : "bg-muted"
                  )}
                />
              )}
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
