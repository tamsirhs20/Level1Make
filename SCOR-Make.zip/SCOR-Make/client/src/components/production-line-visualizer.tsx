import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { cn } from "@/lib/utils";
import { type Workstation } from "@shared/schema";
import { AlertTriangle, CheckCircle, Cog, Wrench, Zap } from "lucide-react";

interface ProductionLineVisualizerProps {
  workstations: Workstation[];
  bottleneckId?: string | null;
  onStationClick?: (station: Workstation) => void;
  className?: string;
}

export function ProductionLineVisualizer({
  workstations,
  bottleneckId,
  onStationClick,
  className,
}: ProductionLineVisualizerProps) {
  const sortedStations = [...workstations].sort((a, b) => a.position - b.position);

  const getAutomationIcon = (level: Workstation["automationLevel"]) => {
    switch (level) {
      case "manual":
        return <Wrench className="h-4 w-4" />;
      case "semi_automated":
        return <Cog className="h-4 w-4" />;
      case "fully_automated":
        return <Zap className="h-4 w-4" />;
    }
  };

  const getUtilizationColor = (station: Workstation) => {
    const utilization = station.performance;
    if (utilization >= 90) return "bg-chart-3/20 border-chart-3";
    if (utilization >= 70) return "bg-chart-2/20 border-chart-2";
    return "bg-destructive/20 border-destructive";
  };

  const calculateOEE = (station: Workstation) => {
    return ((station.availability / 100) * (station.performance / 100) * (station.quality / 100) * 100).toFixed(1);
  };

  return (
    <Card className={cn("", className)} data-testid="production-line-visualizer">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg flex items-center justify-between gap-2 flex-wrap">
          <span>Production Line</span>
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="text-xs">
              {sortedStations.length} Stations
            </Badge>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex items-center gap-2 overflow-x-auto pb-4">
          <div className="flex items-center justify-center w-16 h-16 rounded-md border-2 border-dashed border-muted-foreground/30 flex-shrink-0">
            <span className="text-xs text-muted-foreground">Input</span>
          </div>

          {sortedStations.map((station, index) => (
            <div key={station.id} className="flex items-center gap-2 flex-shrink-0">
              <div className="w-8 h-0.5 bg-muted-foreground/30" />
              
              <Tooltip>
                <TooltipTrigger asChild>
                  <button
                    onClick={() => onStationClick?.(station)}
                    className={cn(
                      "relative flex flex-col items-center justify-center w-24 h-24 rounded-md border-2 transition-all hover-elevate",
                      getUtilizationColor(station),
                      bottleneckId === station.id && "ring-2 ring-destructive ring-offset-2 animate-pulse"
                    )}
                    data-testid={`station-${station.id}`}
                  >
                    {bottleneckId === station.id && (
                      <div className="absolute -top-2 -right-2">
                        <AlertTriangle className="h-5 w-5 text-destructive" />
                      </div>
                    )}
                    {station.qualityCheckpoint && (
                      <div className="absolute -top-2 -left-2">
                        <CheckCircle className="h-4 w-4 text-chart-3" />
                      </div>
                    )}
                    
                    <div className="flex items-center gap-1 mb-1">
                      {getAutomationIcon(station.automationLevel)}
                    </div>
                    <span className="text-xs font-medium text-center line-clamp-1 px-1">
                      {station.name}
                    </span>
                    <span className="text-xs text-muted-foreground font-mono mt-1">
                      {station.cycleTime}s
                    </span>
                  </button>
                </TooltipTrigger>
                <TooltipContent side="bottom" className="max-w-xs">
                  <div className="space-y-1 text-sm">
                    <div className="font-semibold">{station.name}</div>
                    <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-xs">
                      <span className="text-muted-foreground">Cycle Time:</span>
                      <span className="font-mono">{station.cycleTime}s</span>
                      <span className="text-muted-foreground">OEE:</span>
                      <span className="font-mono">{calculateOEE(station)}%</span>
                      <span className="text-muted-foreground">Machines:</span>
                      <span className="font-mono">{station.machineCount}</span>
                      <span className="text-muted-foreground">WIP Limit:</span>
                      <span className="font-mono">{station.wipLimit ?? "None"}</span>
                    </div>
                  </div>
                </TooltipContent>
              </Tooltip>

              {index === sortedStations.length - 1 && (
                <>
                  <div className="w-8 h-0.5 bg-muted-foreground/30" />
                  <div className="flex items-center justify-center w-16 h-16 rounded-md border-2 border-dashed border-muted-foreground/30 flex-shrink-0">
                    <span className="text-xs text-muted-foreground">Output</span>
                  </div>
                </>
              )}
            </div>
          ))}
        </div>

        <div className="flex items-center gap-4 pt-4 border-t flex-wrap">
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <Wrench className="h-3 w-3" />
            <span>Manual</span>
          </div>
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <Cog className="h-3 w-3" />
            <span>Semi-Auto</span>
          </div>
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <Zap className="h-3 w-3" />
            <span>Fully Auto</span>
          </div>
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <CheckCircle className="h-3 w-3 text-chart-3" />
            <span>Quality Check</span>
          </div>
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <AlertTriangle className="h-3 w-3 text-destructive" />
            <span>Bottleneck</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
