import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { type KPI, type RoundType, ROUND_TYPE_CONFIGS } from "@shared/schema";
import { TrendingUp, TrendingDown, Minus, ArrowRight, CheckCircle } from "lucide-react";

interface RoundSummaryPanelProps {
  roundType: RoundType;
  roundNumber: number;
  kpiResults: KPI;
  previousKPI?: KPI | null;
  onNextRound: () => void;
  isLastRound?: boolean;
  className?: string;
}

export function RoundSummaryPanel({
  roundType,
  roundNumber,
  kpiResults,
  previousKPI,
  onNextRound,
  isLastRound = false,
  className,
}: RoundSummaryPanelProps) {
  const calculateChange = (current: number, previous?: number) => {
    if (!previous) return null;
    return ((current - previous) / previous) * 100;
  };

  const getTrendIcon = (change: number | null) => {
    if (change === null || Math.abs(change) < 0.5) return <Minus className="h-4 w-4 text-muted-foreground" />;
    if (change > 0) return <TrendingUp className="h-4 w-4 text-chart-3" />;
    return <TrendingDown className="h-4 w-4 text-destructive" />;
  };

  const formatChange = (change: number | null) => {
    if (change === null) return "N/A";
    const sign = change > 0 ? "+" : "";
    return `${sign}${change.toFixed(1)}%`;
  };

  const kpiItems = [
    {
      label: "Throughput",
      value: kpiResults.throughput,
      unit: " units",
      previous: previousKPI?.throughput,
      higherIsBetter: true,
    },
    {
      label: "OEE",
      value: kpiResults.oeeOverall,
      unit: "%",
      previous: previousKPI?.oeeOverall,
      higherIsBetter: true,
    },
    {
      label: "Utilization",
      value: kpiResults.overallUtilization,
      unit: "%",
      previous: previousKPI?.overallUtilization,
      higherIsBetter: true,
    },
    {
      label: "Defect Rate",
      value: kpiResults.defectRate,
      unit: "%",
      previous: previousKPI?.defectRate,
      higherIsBetter: false,
    },
    {
      label: "Lead Time",
      value: kpiResults.leadTime,
      unit: "s",
      previous: previousKPI?.leadTime,
      higherIsBetter: false,
    },
    {
      label: "Inventory",
      value: kpiResults.inventory,
      unit: " units",
      previous: previousKPI?.inventory,
      higherIsBetter: false,
    },
  ];

  return (
    <Card className={cn("border-2", className)} data-testid="round-summary-panel">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between gap-2 flex-wrap">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-full bg-chart-3/20">
              <CheckCircle className="h-6 w-6 text-chart-3" />
            </div>
            <div>
              <CardTitle className="text-xl">Round {roundNumber} Complete</CardTitle>
              <p className="text-sm text-muted-foreground mt-1">
                {ROUND_TYPE_CONFIGS[roundType].name}
              </p>
            </div>
          </div>
          <Badge variant="outline" className="text-lg px-4 py-2 font-mono">
            OEE: {kpiResults.oeeOverall.toFixed(1)}%
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {kpiItems.map((item) => {
            const change = calculateChange(item.value, item.previous);
            const isImproved =
              change !== null &&
              ((item.higherIsBetter && change > 0) || (!item.higherIsBetter && change < 0));

            return (
              <div
                key={item.label}
                className="p-4 bg-muted/50 rounded-lg text-center"
                data-testid={`summary-${item.label.toLowerCase().replace(/\s+/g, "-")}`}
              >
                <span className="text-xs text-muted-foreground">{item.label}</span>
                <div className="text-2xl font-mono font-semibold mt-1">
                  {typeof item.value === "number" ? item.value.toFixed(1) : item.value}
                  <span className="text-sm text-muted-foreground">{item.unit}</span>
                </div>
                {previousKPI && (
                  <div
                    className={cn(
                      "flex items-center justify-center gap-1 mt-2 text-sm",
                      isImproved ? "text-chart-3" : change !== null && Math.abs(change) > 0.5 ? "text-destructive" : "text-muted-foreground"
                    )}
                  >
                    {getTrendIcon(item.higherIsBetter ? change : change !== null ? -change : null)}
                    <span className="font-mono">{formatChange(change)}</span>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 border rounded-lg">
            <h4 className="text-sm font-medium mb-2">Availability (A)</h4>
            <div className="text-3xl font-mono font-semibold text-chart-1">
              {kpiResults.oeeAvailability.toFixed(1)}%
            </div>
            <p className="text-xs text-muted-foreground mt-2">
              Equipment uptime vs planned time
            </p>
          </div>

          <div className="p-4 border rounded-lg">
            <h4 className="text-sm font-medium mb-2">Performance (P)</h4>
            <div className="text-3xl font-mono font-semibold text-chart-2">
              {kpiResults.oeePerformance.toFixed(1)}%
            </div>
            <p className="text-xs text-muted-foreground mt-2">
              Actual vs theoretical speed
            </p>
          </div>

          <div className="p-4 border rounded-lg">
            <h4 className="text-sm font-medium mb-2">Quality (Q)</h4>
            <div className="text-3xl font-mono font-semibold text-chart-3">
              {kpiResults.oeeQuality.toFixed(1)}%
            </div>
            <p className="text-xs text-muted-foreground mt-2">
              Good products vs total output
            </p>
          </div>
        </div>

        {kpiResults.bottleneckStation && (
          <div className="p-4 bg-destructive/10 border border-destructive/30 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <TrendingDown className="h-5 w-5 text-destructive" />
              <h4 className="font-medium text-destructive">Bottleneck Identified</h4>
            </div>
            <p className="text-sm text-muted-foreground">
              Station <span className="font-medium">{kpiResults.bottleneckStation}</span> is limiting throughput.
              Consider adding machines or reducing cycle time.
            </p>
          </div>
        )}

        <div className="flex justify-end pt-4 border-t">
          <Button onClick={onNextRound} size="lg" data-testid="button-next-round">
            {isLastRound ? "Complete Session" : "Next Round"}
            <ArrowRight className="h-5 w-5 ml-2" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
