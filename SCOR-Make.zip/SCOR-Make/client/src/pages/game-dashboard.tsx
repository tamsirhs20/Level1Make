import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { ThemeToggle } from "@/components/theme-toggle";
import { KPICard } from "@/components/kpi-card";
import { OEEDashboard } from "@/components/oee-dashboard";
import { ProductionLineVisualizer } from "@/components/production-line-visualizer";
import { RoundProgress } from "@/components/round-progress";
import { RoundSummaryPanel } from "@/components/round-summary-panel";
import { ProductionPlannerModule } from "@/components/role-modules/production-planner-module";
import { CapacityEngineerModule } from "@/components/role-modules/capacity-engineer-module";
import { LeanQualityModule } from "@/components/role-modules/lean-quality-module";
import { AutomationEngineerModule } from "@/components/role-modules/automation-engineer-module";
import { useGame } from "@/lib/game-context";
import { ROLE_CONFIGS, ROUND_TYPE_CONFIGS, type TeamRole, type RoundType } from "@shared/schema";
import { 
  Factory, 
  Play, 
  Users, 
  Clock,
  ClipboardList,
  Settings,
  Shield,
  Cpu,
  BarChart3,
  Loader2,
  Home,
  type LucideIcon
} from "lucide-react";

const roleIconMap: Record<string, LucideIcon> = {
  production_planner: ClipboardList,
  capacity_engineer: Settings,
  lean_quality_engineer: Shield,
  automation_engineer: Cpu,
  performance_analyst: BarChart3,
};

export default function GameDashboard() {
  const [, setLocation] = useLocation();
  const { 
    session, 
    currentRound, 
    selectedRole, 
    setSelectedRole,
    startSimulation,
    isSimulating,
    advanceToNextRound,
    setSession
  } = useGame();

  const [activeTab, setActiveTab] = useState<string>(selectedRole || "production_planner");

  useEffect(() => {
    if (!session) {
      setLocation("/");
    }
  }, [session, setLocation]);

  if (!session || !currentRound) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  const roundTypes = session.rounds.map((r) => r.roundType);
  const completedRounds = session.rounds
    .filter((r) => r.completedAt !== null)
    .map((_, i) => i);

  const previousKPI = session.currentRoundIndex > 0
    ? session.rounds[session.currentRoundIndex - 1]?.kpiResults
    : null;

  const handleNextRound = () => {
    if (session.currentRoundIndex < session.rounds.length - 1) {
      advanceToNextRound();
    } else {
      setLocation("/");
    }
  };

  const RoleIcon = roleIconMap[selectedRole || "production_planner"];

  const renderRoleModule = () => {
    switch (activeTab) {
      case "production_planner":
        return <ProductionPlannerModule />;
      case "capacity_engineer":
        return <CapacityEngineerModule />;
      case "lean_quality_engineer":
        return <LeanQualityModule />;
      case "automation_engineer":
        return <AutomationEngineerModule />;
      default:
        return <ProductionPlannerModule />;
    }
  };

  const kpiValues = currentRound.kpiResults || {
    throughput: 0,
    overallUtilization: 0,
    oeeOverall: 0,
    defectRate: 0,
    leadTime: 0,
    inventory: 0,
    backlog: 0,
    oeeAvailability: 85,
    oeePerformance: 80,
    oeeQuality: 95,
    utilizationByStation: {},
    reworkRate: 0,
    bottleneckStation: null as string | null,
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <header className="sticky top-0 z-50 bg-background/95 backdrop-blur border-b">
        <div className="px-4 h-16 flex items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setLocation("/")}
              data-testid="button-home"
            >
              <Home className="h-5 w-5" />
            </Button>
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-md bg-primary/10">
                <Factory className="h-5 w-5 text-primary" />
              </div>
              <div>
                <h1 className="font-semibold">{session.team.name}</h1>
                <p className="text-xs text-muted-foreground">
                  {ROUND_TYPE_CONFIGS[currentRound.roundType].name}
                </p>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <Badge 
              variant={currentRound.phase === "design" ? "default" : currentRound.phase === "simulating" ? "secondary" : "outline"}
              className="gap-2"
              data-testid="badge-phase"
            >
              {currentRound.phase === "simulating" && <Loader2 className="h-3 w-3 animate-spin" />}
              {currentRound.phase.charAt(0).toUpperCase() + currentRound.phase.slice(1)} Phase
            </Badge>
            
            <div className="flex items-center gap-2">
              <Users className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm">{session.team.members.length} member(s)</span>
            </div>

            <div className="flex items-center gap-2">
              <RoleIcon className="h-4 w-4 text-primary" />
              <span className="text-sm font-medium">
                {ROLE_CONFIGS.find((r) => r.id === selectedRole)?.name}
              </span>
            </div>

            <ThemeToggle />
          </div>
        </div>
      </header>

      <main className="flex-1 p-4 space-y-6">
        <RoundProgress
          currentRound={session.currentRoundIndex}
          totalRounds={session.rounds.length}
          roundTypes={roundTypes}
          completedRounds={completedRounds}
        />

        {currentRound.phase === "reviewing" && currentRound.kpiResults ? (
          <RoundSummaryPanel
            roundType={currentRound.roundType}
            roundNumber={session.currentRoundIndex}
            kpiResults={currentRound.kpiResults}
            previousKPI={previousKPI}
            onNextRound={handleNextRound}
            isLastRound={session.currentRoundIndex === session.rounds.length - 1}
          />
        ) : (
          <>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
              <KPICard
                label="Throughput"
                value={kpiValues.throughput}
                unit=" units"
                variant={kpiValues.throughput > 100 ? "success" : "default"}
              />
              <KPICard
                label="OEE"
                value={`${kpiValues.oeeOverall.toFixed(1)}`}
                unit="%"
                target={85}
                variant={kpiValues.oeeOverall >= 85 ? "success" : kpiValues.oeeOverall >= 60 ? "warning" : "danger"}
              />
              <KPICard
                label="Utilization"
                value={`${kpiValues.overallUtilization.toFixed(1)}`}
                unit="%"
                target={80}
              />
              <KPICard
                label="Defect Rate"
                value={`${kpiValues.defectRate.toFixed(1)}`}
                unit="%"
                variant={kpiValues.defectRate <= 3 ? "success" : kpiValues.defectRate <= 5 ? "warning" : "danger"}
              />
              <KPICard
                label="Lead Time"
                value={`${kpiValues.leadTime.toFixed(0)}`}
                unit="s"
              />
              <KPICard
                label="Inventory"
                value={kpiValues.inventory}
                unit=" units"
              />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2 space-y-6">
                <ProductionLineVisualizer
                  workstations={currentRound.configuration.productionLine.workstations}
                  bottleneckId={kpiValues.bottleneckStation}
                />

                <Card>
                  <CardHeader className="pb-2">
                    <div className="flex items-center justify-between gap-2 flex-wrap">
                      <CardTitle className="text-lg">Role Configuration</CardTitle>
                      {currentRound.phase === "design" && (
                        <Button
                          onClick={startSimulation}
                          disabled={isSimulating}
                          data-testid="button-run-simulation"
                        >
                          {isSimulating ? (
                            <>
                              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                              Simulating...
                            </>
                          ) : (
                            <>
                              <Play className="h-4 w-4 mr-2" />
                              Run Simulation
                            </>
                          )}
                        </Button>
                      )}
                    </div>
                  </CardHeader>
                  <CardContent>
                    <Tabs value={activeTab} onValueChange={setActiveTab}>
                      <TabsList className="w-full justify-start flex-wrap h-auto gap-1">
                        {ROLE_CONFIGS.filter((r) => r.id !== "performance_analyst").map((role) => {
                          const Icon = roleIconMap[role.id];
                          return (
                            <TabsTrigger
                              key={role.id}
                              value={role.id}
                              className="gap-2"
                              data-testid={`tab-${role.id}`}
                            >
                              <Icon className="h-4 w-4" />
                              <span className="hidden sm:inline">{role.name}</span>
                            </TabsTrigger>
                          );
                        })}
                      </TabsList>

                      <div className="mt-4">
                        <ScrollArea className="h-[500px]">
                          {renderRoleModule()}
                        </ScrollArea>
                      </div>
                    </Tabs>
                  </CardContent>
                </Card>
              </div>

              <div className="space-y-6">
                <OEEDashboard
                  availability={kpiValues.oeeAvailability}
                  performance={kpiValues.oeePerformance}
                  quality={kpiValues.oeeQuality}
                />

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">Round Info</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Round</span>
                      <span className="font-mono">{session.currentRoundIndex + 1} / {session.rounds.length}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Type</span>
                      <Badge variant="outline">
                        {ROUND_TYPE_CONFIGS[currentRound.roundType].name}
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Duration</span>
                      <span className="flex items-center gap-1">
                        <Clock className="h-4 w-4" />
                        {ROUND_TYPE_CONFIGS[currentRound.roundType].duration} min
                      </span>
                    </div>
                    <div className="pt-4 border-t">
                      <p className="text-sm text-muted-foreground">
                        {ROUND_TYPE_CONFIGS[currentRound.roundType].description}
                      </p>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">Team Members</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {session.team.members.map((member) => {
                      const role = ROLE_CONFIGS.find((r) => r.id === member.role);
                      const Icon = roleIconMap[member.role];
                      return (
                        <div
                          key={member.id}
                          className="flex items-center gap-3 p-2 rounded-md bg-muted/50"
                        >
                          <div className="p-2 rounded-md bg-background">
                            <Icon className="h-4 w-4" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="font-medium truncate">{member.name}</div>
                            <div className="text-xs text-muted-foreground truncate">
                              {role?.name}
                            </div>
                          </div>
                          <Badge variant="outline" className="text-xs">
                            Active
                          </Badge>
                        </div>
                      );
                    })}
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">Configuration Summary</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3 text-sm">
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground">Products</span>
                      <span className="font-mono">{currentRound.configuration.products.length}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground">Workstations</span>
                      <span className="font-mono">{currentRound.configuration.productionLine.workstations.length}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground">WIP Limits</span>
                      <Badge variant={currentRound.configuration.leanInitiatives.wipLimitsEnabled ? "default" : "secondary"}>
                        {currentRound.configuration.leanInitiatives.wipLimitsEnabled ? "On" : "Off"}
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground">Quality Checks</span>
                      <Badge variant={currentRound.configuration.leanInitiatives.qualityCheckpointsEnabled ? "default" : "secondary"}>
                        {currentRound.configuration.leanInitiatives.qualityCheckpointsEnabled ? "On" : "Off"}
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground">Automation</span>
                      <Badge variant="outline">
                        {currentRound.configuration.automationSettings.targetAutomationLevel.replace("_", " ")}
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground">Maintenance</span>
                      <Badge variant={currentRound.configuration.automationSettings.preventiveMaintenance ? "default" : "secondary"}>
                        {currentRound.configuration.automationSettings.preventiveMaintenance ? "On" : "Off"}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </>
        )}
      </main>
    </div>
  );
}
