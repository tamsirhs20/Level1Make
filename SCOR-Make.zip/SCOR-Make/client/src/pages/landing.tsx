import { useState } from "react";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { RoleCard } from "@/components/role-card";
import { ThemeToggle } from "@/components/theme-toggle";
import { ROLE_CONFIGS, ROUND_TYPE_CONFIGS, type TeamRole, type RoundType, type GameSession } from "@shared/schema";
import { useGame } from "@/lib/game-context";
import { apiRequest } from "@/lib/queryClient";
import { 
  Factory, 
  Play, 
  Users, 
  Target, 
  BarChart3, 
  Cog,
  ArrowRight,
  CheckCircle
} from "lucide-react";

function createInitialSession(teamName: string, playerName: string, selectedRole: TeamRole) {
  const sessionId = `session-${Date.now()}`;
  const playerId = `player-${Date.now()}`;

  const initialWorkstations = [
    {
      id: "ws-1",
      name: "Assembly A",
      position: 1,
      cycleTime: 30,
      automationLevel: "manual" as const,
      operatorCount: 2,
      machineCount: 1,
      wipLimit: null,
      qualityCheckpoint: false,
      maintenanceSchedule: "none" as const,
      availability: 85,
      performance: 80,
      quality: 95,
    },
    {
      id: "ws-2",
      name: "Processing B",
      position: 2,
      cycleTime: 45,
      automationLevel: "manual" as const,
      operatorCount: 1,
      machineCount: 1,
      wipLimit: null,
      qualityCheckpoint: false,
      maintenanceSchedule: "none" as const,
      availability: 82,
      performance: 78,
      quality: 92,
    },
    {
      id: "ws-3",
      name: "Quality Check",
      position: 3,
      cycleTime: 20,
      automationLevel: "manual" as const,
      operatorCount: 1,
      machineCount: 1,
      wipLimit: null,
      qualityCheckpoint: true,
      maintenanceSchedule: "none" as const,
      availability: 90,
      performance: 85,
      quality: 98,
    },
    {
      id: "ws-4",
      name: "Packaging",
      position: 4,
      cycleTime: 25,
      automationLevel: "manual" as const,
      operatorCount: 2,
      machineCount: 2,
      wipLimit: null,
      qualityCheckpoint: false,
      maintenanceSchedule: "none" as const,
      availability: 88,
      performance: 82,
      quality: 96,
    },
  ];

  const initialProducts = [
    {
      id: "prod-1",
      name: "Product Alpha",
      mode: "MTS" as const,
      demandRate: 50,
      baseProcessingTime: 120,
      lotSize: 100,
      safetyStock: 50,
    },
    {
      id: "prod-2",
      name: "Product Beta",
      mode: "MTO" as const,
      demandRate: 30,
      baseProcessingTime: 150,
      lotSize: 50,
      safetyStock: 0,
    },
  ];

  const roundTypes: RoundType[] = ["practice", "baseline", "lean_quality", "automation"];

  const rounds = roundTypes.map((roundType, index) => ({
    id: `round-${index}`,
    roundNumber: index,
    roundType,
    phase: index === 0 ? "design" as const : "design" as const,
    configuration: {
      products: [...initialProducts],
      productionLine: {
        id: "line-1",
        name: "Main Production Line",
        workstations: [...initialWorkstations],
        shiftHours: 8,
        operatingDays: 5,
      },
      leanInitiatives: {
        wipLimitsEnabled: false,
        qualityCheckpointsEnabled: false,
        layoutOptimized: false,
      },
      automationSettings: {
        targetAutomationLevel: "manual" as const,
        preventiveMaintenance: false,
      },
    },
    kpiResults: null,
    startedAt: null,
    completedAt: null,
  }));

  return {
    id: sessionId,
    name: `${teamName} - Session`,
    team: {
      id: `team-${Date.now()}`,
      name: teamName,
      sessionId,
      members: [
        {
          id: playerId,
          name: playerName,
          role: selectedRole,
        },
      ],
    },
    currentRoundIndex: 0,
    rounds,
    status: "active" as const,
    createdAt: new Date().toISOString(),
  };
}

export default function Landing() {
  const [, setLocation] = useLocation();
  const { setSession, setSelectedRole } = useGame();
  const [teamName, setTeamName] = useState("");
  const [playerName, setPlayerName] = useState("");
  const [selectedRoleId, setSelectedRoleId] = useState<TeamRole | null>(null);
  const [step, setStep] = useState<"intro" | "setup">("intro");

  const [isCreating, setIsCreating] = useState(false);

  const handleStartGame = async () => {
    if (!teamName || !playerName || !selectedRoleId || isCreating) {
      return;
    }

    setIsCreating(true);
    
    const localSession = createInitialSession(teamName, playerName, selectedRoleId);
    
    try {
      const timeoutPromise = new Promise<never>((_, reject) => 
        setTimeout(() => reject(new Error("Timeout")), 3000)
      );
      
      const apiPromise = apiRequest("POST", "/api/sessions", localSession)
        .then(response => response.json() as Promise<GameSession>);
      
      const savedSession = await Promise.race([apiPromise, timeoutPromise]);
      
      setSession({
        ...savedSession,
        rounds: savedSession.rounds || localSession.rounds,
      });
    } catch (error) {
      setSession(localSession);
    }
    
    setSelectedRole(selectedRoleId);
    setIsCreating(false);
    setLocation("/game");
  };

  const features = [
    {
      icon: Factory,
      title: "Production Simulation",
      description: "Configure MTS and MTO strategies for realistic manufacturing scenarios",
    },
    {
      icon: BarChart3,
      title: "Real-time KPIs",
      description: "Track OEE, utilization, throughput, and quality metrics live",
    },
    {
      icon: Cog,
      title: "Automation & Lean",
      description: "Apply lean principles and automation to optimize production",
    },
    {
      icon: Users,
      title: "Team Collaboration",
      description: "Work together with specialized roles to achieve targets",
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <header className="fixed top-0 left-0 right-0 z-50 bg-background/95 backdrop-blur border-b">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-md bg-primary/10">
              <Factory className="h-6 w-6 text-primary" />
            </div>
            <div>
              <h1 className="font-semibold text-lg">SSG-Make</h1>
              <p className="text-xs text-muted-foreground">SCOR Level 1 Simulation</p>
            </div>
          </div>
          <ThemeToggle />
        </div>
      </header>

      <main className="pt-16">
        {step === "intro" ? (
          <>
            <section className="relative py-20 px-4">
              <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-chart-3/5" />
              <div className="relative max-w-4xl mx-auto text-center">
                <Badge variant="outline" className="mb-6">
                  Serious Simulation Game
                </Badge>
                <h2 className="text-4xl md:text-5xl font-bold tracking-tight mb-6">
                  Master Production Operations
                </h2>
                <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-8">
                  Learn to design, run, and optimize manufacturing processes through 
                  interactive simulation. Experience Make-to-Stock and Make-to-Order 
                  strategies without real-world risk.
                </p>
                <div className="flex items-center justify-center gap-4 flex-wrap">
                  <Button size="lg" onClick={() => setStep("setup")} data-testid="button-start-game">
                    Start Simulation
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Button>
                  <Button variant="outline" size="lg" data-testid="button-learn-more">
                    Learn More
                  </Button>
                </div>
              </div>
            </section>

            <section className="py-16 px-4 bg-muted/30">
              <div className="max-w-6xl mx-auto">
                <h3 className="text-2xl font-semibold text-center mb-12">
                  What You'll Learn
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  {features.map((feature) => (
                    <Card key={feature.title} className="text-center">
                      <CardContent className="pt-6">
                        <div className="p-3 rounded-full bg-primary/10 w-fit mx-auto mb-4">
                          <feature.icon className="h-6 w-6 text-primary" />
                        </div>
                        <h4 className="font-semibold mb-2">{feature.title}</h4>
                        <p className="text-sm text-muted-foreground">
                          {feature.description}
                        </p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            </section>

            <section className="py-16 px-4">
              <div className="max-w-4xl mx-auto">
                <h3 className="text-2xl font-semibold text-center mb-12">
                  Simulation Rounds
                </h3>
                <div className="space-y-4">
                  {(["practice", "baseline", "lean_quality", "automation"] as RoundType[]).map(
                    (roundType, index) => (
                      <div
                        key={roundType}
                        className="flex items-center gap-4 p-4 border rounded-lg"
                      >
                        <div className="flex items-center justify-center w-10 h-10 rounded-full bg-primary/10 text-primary font-semibold">
                          {index}
                        </div>
                        <div className="flex-1">
                          <h4 className="font-medium">
                            {ROUND_TYPE_CONFIGS[roundType].name}
                          </h4>
                          <p className="text-sm text-muted-foreground">
                            {ROUND_TYPE_CONFIGS[roundType].description}
                          </p>
                        </div>
                        <Badge variant="outline">
                          {ROUND_TYPE_CONFIGS[roundType].duration} min
                        </Badge>
                      </div>
                    )
                  )}
                </div>
              </div>
            </section>
          </>
        ) : (
          <section className="py-12 px-4">
            <div className="max-w-4xl mx-auto">
              <Button
                variant="ghost"
                onClick={() => setStep("intro")}
                className="mb-6"
                data-testid="button-back"
              >
                Back to Overview
              </Button>

              <Card>
                <CardHeader>
                  <CardTitle className="text-2xl">Start Your Simulation</CardTitle>
                  <CardDescription>
                    Set up your team and select your role to begin
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-8">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="team-name">Team Name</Label>
                      <Input
                        id="team-name"
                        placeholder="Enter your team name"
                        value={teamName}
                        onChange={(e) => setTeamName(e.target.value)}
                        data-testid="input-team-name"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="player-name">Your Name</Label>
                      <Input
                        id="player-name"
                        placeholder="Enter your name"
                        value={playerName}
                        onChange={(e) => setPlayerName(e.target.value)}
                        data-testid="input-player-name"
                      />
                    </div>
                  </div>

                  <div className="space-y-4">
                    <Label>Select Your Role</Label>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {ROLE_CONFIGS.filter((r) => r.id !== "performance_analyst").map(
                        (role) => (
                          <RoleCard
                            key={role.id}
                            role={role}
                            isSelected={selectedRoleId === role.id}
                            onClick={() => setSelectedRoleId(role.id)}
                          />
                        )
                      )}
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-6 border-t gap-4 flex-wrap">
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <CheckCircle className={teamName ? "text-chart-3" : ""} />
                      <span className={teamName ? "" : "text-muted-foreground"}>Team name</span>
                      <CheckCircle className={playerName ? "text-chart-3" : ""} />
                      <span className={playerName ? "" : "text-muted-foreground"}>Your name</span>
                      <CheckCircle className={selectedRoleId ? "text-chart-3" : ""} />
                      <span className={selectedRoleId ? "" : "text-muted-foreground"}>Role selected</span>
                    </div>
                    <Button
                      size="lg"
                      disabled={!teamName || !playerName || !selectedRoleId || isCreating}
                      onClick={handleStartGame}
                      data-testid="button-begin-simulation"
                    >
                      {isCreating ? "Starting..." : "Begin Simulation"}
                      <Play className="ml-2 h-5 w-5" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </section>
        )}
      </main>

      <footer className="py-8 px-4 border-t bg-muted/30">
        <div className="max-w-7xl mx-auto text-center text-sm text-muted-foreground">
          <p>SCOR Level 1 Make - Serious Simulation Game</p>
          <p className="mt-1">Production Operations Management Training</p>
        </div>
      </footer>
    </div>
  );
}
